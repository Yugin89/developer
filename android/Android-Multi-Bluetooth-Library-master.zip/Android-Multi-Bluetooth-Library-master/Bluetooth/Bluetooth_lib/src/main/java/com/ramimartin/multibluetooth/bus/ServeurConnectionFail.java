package com.ramimartin.multibluetooth.bus;

/**
 * Created by Rami MARTIN on 13/04/2014.
 */
public class ServeurConnectionFail {

    public String mClientAdressConnectionFail;

    public ServeurConnectionFail(String clientAdressConnectionFail){
        mClientAdressConnectionFail = clientAdressConnectionFail;
    }
}
