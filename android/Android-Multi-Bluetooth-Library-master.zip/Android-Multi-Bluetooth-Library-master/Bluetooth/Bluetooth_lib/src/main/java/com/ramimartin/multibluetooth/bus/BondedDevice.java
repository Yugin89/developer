package com.ramimartin.multibluetooth.bus;

/**
 * Created by Rami MARTIN on 21/04/2014.
 */
public class BondedDevice {
}
