package com.ramimartin.multibluetooth.bus;

/**
 * Created by Rami on 14/06/2017.
 */
public class BluetoothCommunicatorObject {

    public Object mObject;

    public BluetoothCommunicatorObject(Object object) {
        this.mObject = object;
    }
}
